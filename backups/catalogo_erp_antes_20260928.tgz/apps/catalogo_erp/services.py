"""Conexión al ERP (PostgreSQL) y construcción de búsquedas de productos.

Solo lectura y con ``statement_timeout``. Todos los *valores* de las
consultas pasan como parámetros ``%s`` de psycopg2; los *identificadores*
(tablas, columnas, esquema) se citan con ``psycopg2.sql`` para evitar
inyección por configuración.
"""

import logging

import psycopg2
from psycopg2 import sql

from apps.catalogo_erp.models import CategoriaProductoERP

logger = logging.getLogger(__name__)

LIMITE_RESULTADOS = 50
TIMEOUT_CONEXION_S = 8
TIMEOUT_STATEMENT_MS = 4000


class CatalogoError(Exception):
    """Error controlado del catálogo (mensaje amigable para el usuario)."""


def _error_amigable(exc):
    """Traduce excepciones de psycopg2 a mensajes claros."""
    if isinstance(exc, psycopg2.OperationalError):
        return "No se pudo conectar con el ERP. Verificá la configuración y que la red permita el acceso."
    if isinstance(exc, psycopg2.errors.UndefinedTable):
        codigo = exc.diag.sqlstate or ""
        detalle = getattr(exc, "diag", None) and exc.diag.message_primary or str(exc)
        return f"Tabla inexistente en el ERP ({codigo}): {detalle}"
    if isinstance(exc, psycopg2.errors.UndefinedColumn):
        return f"Columna inexistente en el ERP: {getattr(exc.diag, 'message_primary', str(exc))}"
    if isinstance(exc, psycopg2.errors.QueryCanceled):
        return "La consulta tardó demasiado y fue cancelada. Intentá un criterio más específico."
    return f"Error consultando el ERP: {exc.__class__.__name__}"


def abrir_conexion(config):
    """Conecta a PostgreSQL en modo solo lectura con timeout corto."""
    conn = psycopg2.connect(
        host=config.host,
        port=config.puerto,
        dbname=config.nombre_bd,
        user=config.usuario,
        password=config.password_plana,
        connect_timeout=TIMEOUT_CONEXION_S,
        options=(
            f"-c statement_timeout={TIMEOUT_STATEMENT_MS} "
            "-c default_transaction_read_only=on"
        ),
    )
    return conn


def probar_conexion(config):
    """Prueba la conexión (SELECT 1). Devuelve (ok, mensaje)."""
    try:
        with abrir_conexion(config) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        return True, "Conexión exitosa al ERP."
    except Exception as exc:  # noqa: BLE001 - se traduce a mensaje
        logger.exception("Prueba de conexión ERP fallida")
        return False, _error_amigable(exc)


# ---------------------------------------------------------------------------
# Construcción de la consulta (identificadores citados, valores parametrizados)
# ---------------------------------------------------------------------------
def _columna(tabla_alias, nombre):
    """Columna ``alias.nombre`` con identificadores citados."""
    return sql.SQL(".").join((sql.Identifier(tabla_alias), sql.Identifier(nombre)))


def _consulta_personalizada(categoria, terminos):
    """Procesa una consulta SQL personalizada con placeholders :q1, :q2, :q3.

    Valida que sea SELECT y reemplaza los placeholders por parámetros seguros.
    """
    raw_sql = categoria.consulta_sql.strip()

    # Validación básica de seguridad: solo SELECT
    normalized = " ".join(raw_sql.lower().split())
    if not normalized.startswith("select"):
        raise CatalogoError(
            "La consulta personalizada debe empezar con SELECT. "
            "No se permiten INSERT, UPDATE, DELETE ni otras operaciones."
        )

    if ";" in raw_sql.rstrip(";").rstrip():
        raise CatalogoError(
            "La consulta personalizada no debe contener puntos y coma (;)."
        )

    # Mapeo de placeholders a valores del buscador
    valores = {
        ":q1": (terminos.get("q1") or "").strip(),
        ":q2": (terminos.get("q2") or "").strip(),
        ":q3": (terminos.get("q3") or "").strip(),
    }

    # Verificar que al menos un placeholder tenga valor
    placeholders_requeridos = set()
    for placeholder in (":q1", ":q2", ":q3"):
        if placeholder in raw_sql:
            placeholders_requeridos.add(placeholder)

    if placeholders_requeridos and not any(valores[p] for p in placeholders_requeridos):
        raise CatalogoError(
            "Ingresá al menos un criterio de búsqueda para esta categoría."
        )

    # Reemplazar cada placeholder por %s (parámetro seguro)
    params = []
    sql_safe = raw_sql
    for placeholder in (":q1", ":q2", ":q3"):
        if placeholder in sql_safe:
            sql_safe = sql_safe.replace(placeholder, "%s", 1)
            params.append(valores[placeholder])

    # Agregar LIMIT si no tiene
    if "limit" not in normalized:
        sql_safe += f" LIMIT {LIMITE_RESULTADOS}"

    return sql.SQL(sql_safe), params


def construir_consulta(categoria, config, terminos):
    """Devuelve (sql, params) para buscar productos y su disponibilidad.

    ``terminos``: dict con ``q`` (un solo criterio) o ``q1``/``q2``/``q3``
    (método "multiple").
    """

    def campo(nombre):
        if not nombre:
            return None
        return _columna("p", nombre)

    def extra(nombre):
        sql_expr = campo(nombre)
        if sql_expr is None:
            return None
        return sql.SQL("").join((sql_expr, sql.SQL(" AS "), sql.Identifier("extra")))

    # --- Consulta personalizada del admin --------------------------------
    if categoria.usar_consulta_personalizada and categoria.consulta_sql.strip():
        return _consulta_personalizada(categoria, terminos)

    # Columnas seleccionadas
    extras_config = [
        categoria.campo_extra1,
        categoria.campo_extra2,
        categoria.campo_extra3,
    ]
    seleccion = [
        _columna("p", categoria.campo_codigo) + sql.SQL(" AS codigo"),
        _columna("p", categoria.campo_nombre) + sql.SQL(" AS nombre"),
    ]
    for i, nombre_extra in enumerate(extras_config, start=1):
        if nombre_extra:
            seleccion.append(_columna("p", nombre_extra) + sql.SQL(f" AS extra{i}"))

    seleccion += [
        sql.SQL("COALESCE(d.{dep_nombre}, s.{dep_codigo_stock})").format(
            dep_nombre=sql.Identifier(config.campo_dep_nombre),
            dep_codigo_stock=sql.Identifier(config.campo_stock_dependencia),
        ) + sql.SQL(" AS dependencia"),
        sql.SQL("COALESCE(s.{cant}, 0)").format(
            cant=sql.Identifier(config.campo_stock_cantidad)
        ) + sql.SQL(" AS cantidad"),
    ]

    base = sql.SQL(
        "SELECT {seleccion} "
        "FROM {schema}.{origen} AS p "
        "LEFT JOIN {schema}.{stock} AS s "
        "  ON s.{stock_codigo}::text = p.{codigo}::text "
        "LEFT JOIN {schema}.{deps} AS d "
        "  ON d.{dep_codigo}::text = s.{stock_dep}::text "
    ).format(
        seleccion=sql.SQL(", ").join(seleccion),
        schema=sql.Identifier(config.schema),
        origen=sql.Identifier(categoria.tabla_origen),
        stock=sql.Identifier(config.tabla_stock),
        stock_codigo=sql.Identifier(config.campo_stock_codigo),
        stock_dep=sql.Identifier(config.campo_stock_dependencia),
        codigo=sql.Identifier(categoria.campo_codigo),
        deps=sql.Identifier(config.tabla_dependencias),
        dep_codigo=sql.Identifier(config.campo_dep_codigo),
    )

    condiciones = []
    params = []

    def like(columna, valor, prefijo=False, contener=True):
        if prefijo:
            params.append(f"{valor}%")
        elif contener:
            params.append(f"%{valor}%")
        else:
            params.append(valor)
        return sql.SQL("{col} ILIKE {p}").format(col=columna, p=sql.Placeholder())

    metodo = categoria.metodo_busqueda
    q = (terminos.get("q") or "").strip()

    if metodo == CategoriaProductoERP.METODO_CODIGO:
        if not q:
            raise CatalogoError("Ingresá el código exacto del producto para buscar.")
        condiciones.append(
            sql.SQL("{col} = {p}").format(
                col=_columna("p", categoria.campo_codigo), p=sql.Placeholder()
            )
        )
        params.append(q)

    elif metodo == CategoriaProductoERP.METODO_SEGMENTO:
        if not q:
            raise CatalogoError("Ingresá el segmento / prefijo del código para buscar.")
        condiciones.append(like(_columna("p", categoria.campo_codigo), q, prefijo=True))

    elif metodo == CategoriaProductoERP.METODO_DESCRIPCION:
        if not q:
            raise CatalogoError("Ingresá una palabra clave de la descripción para buscar.")
        condiciones.append(
            sql.SQL("({a} ILIKE {p1} OR {b} ILIKE {p2})").format(
                a=_columna("p", categoria.campo_nombre),
                b=_columna("p", categoria.campo_codigo),
                p1=sql.Placeholder(),
                p2=sql.Placeholder(),
            )
        )
        params += [f"%{q}%", f"%{q}%"]

    elif metodo == CategoriaProductoERP.METODO_MULTIPLE:
        objetivos = [categoria.campo_codigo, categoria.campo_nombre]
        if categoria.campo_extra1:
            objetivos.append(categoria.campo_extra1)
        valores = [
            (terminos.get("q1") or "").strip(),
            (terminos.get("q2") or "").strip(),
            (terminos.get("q3") or "").strip(),
        ]
        activas = [(col, val) for col, val in zip(objetivos, valores) if val]
        if not activas:
            raise CatalogoError("Ingresá al menos un criterio de búsqueda.")
        for col, val in activas:
            condiciones.append(like(_columna("p", col), val, contener=True))

    else:  # pragma: no cover - método desconocido
        raise CatalogoError("Método de búsqueda no soportado para esta categoría.")

    if categoria.campo_categoria and categoria.valor_categoria:
        condiciones.append(
            sql.SQL("{col} = {p}").format(
                col=_columna("p", categoria.campo_categoria), p=sql.Placeholder()
            )
        )
        params.append(categoria.valor_categoria)

    consulta = sql.SQL(" {where} {order} {limite}").format(
        where=sql.SQL("WHERE ") + sql.SQL(" AND ").join(condiciones),
        order=sql.SQL(
            "ORDER BY p.{codigo} ASC, dependencia ASC"
        ).format(codigo=sql.Identifier(categoria.campo_codigo)),
        limite=sql.SQL("LIMIT {}").format(
            sql.SQL("{}").format(sql.Literal(LIMITE_RESULTADOS))
        ),
    )

    return base + consulta, params


# ---------------------------------------------------------------------------
# Ejecución y agrupación de resultados
# ---------------------------------------------------------------------------
def _agrupar(filas, extras):
    """Agrupa filas (producto × dependencia) por producto y suma cantidades."""
    productos, orden = {}, []
    for fila in filas:
        codigo, nombre = fila[0], fila[1]
        valores_extra = fila[2 : 2 + extras]
        dependencia, cantidad = fila[2 + extras], fila[3 + extras]
        if codigo is None:
            continue
        if codigo not in productos:
            productos[codigo] = {
                "codigo": codigo,
                "nombre": nombre,
                "extra1": None,
                "extra2": None,
                "extra3": None,
                "disponibilidad": {},
            }
            orden.append(codigo)
            for i, v in enumerate(valores_extra):
                productos[codigo][f"extra{i + 1}"] = v
        resumen = productos[codigo]
        deps = resumen["disponibilidad"]
        deps[dependencia] = deps.get(dependencia, 0) + (cantidad or 0)

    for codigo in orden:
        disponibilidad = [
            {"dependencia": dep, "cantidad": cant}
            for dep, cant in productos[codigo]["disponibilidad"].items()
        ]
        productos[codigo]["disponibilidad"] = disponibilidad
    return [productos[codigo] for codigo in orden]


def buscar_productos(categoria, terminos):
    """Consulta el ERP y devuelve la lista de productos con disponibilidad."""
    from apps.catalogo_erp.models import ConfiguracionERP

    config = ConfiguracionERP.activa()
    if config is None:
        raise CatalogoError(
            "El catálogo no está configurado todavía. Activá la Configuración ERP desde el panel."
        )
    if not categoria or not categoria.activo:
        raise CatalogoError("La categoría solicitada no está disponible.")

    sql_query, params = construir_consulta(categoria, config, terminos)
    usa_personalizada = categoria.usar_consulta_personalizada and categoria.consulta_sql.strip()

    try:
        with abrir_conexion(config) as conn:
            with conn.cursor() as cur:
                cur.execute(sql_query, params)
                filas = cur.fetchall()
                if usa_personalizada:
                    extras = len(cur.description) - 4 if cur.description else 0
                else:
                    extras = sum(
                        1 for c in (categoria.campo_extra1, categoria.campo_extra2, categoria.campo_extra3) if c
                    )
    except psycopg2.Error as exc:
        logger.warning("Fallo ERP (%s): %s", categoria.slug, exc)
        raise CatalogoError(_error_amigable(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        logger.exception("Error inesperado al consultar el ERP")
        raise CatalogoError(_error_amigable(exc)) from exc

    return _agrupar(filas, extras)