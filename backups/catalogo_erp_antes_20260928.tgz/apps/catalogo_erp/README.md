# Módulo Catálogo ERP — Servicios Automotores S.A

Catálogo de productos **conectado al sistema ERP** (PostgreSQL). El sitio solo
almacena *categorías*; la disponibilidad de cada producto se consulta en
tiempo real contra la base del ERP.

## Requisitos

- Django 4+ / Wagtail 5+ (proyecto actual: Django 5.1, Wagtail 6.4).
- `psycopg2-binary` (ya incluido en `requirements.txt`).
- `cryptography` (cifrado de la contraseña; ya incluido en `requirements.txt`).

## Instalación

```bash
pip install -r requirements.txt
python manage.py migrate                                    # crea las tablas del módulo
python manage.py load_catalogo_erp_sample                   # página + config de ejemplo + 3 categorías
```

Agrega la app en `config/settings/base.py` → `INSTALLED_APPS`:
`"apps.catalogo_erp"`. La URL del API se registra en `config/urls.py`
(`/api/catalogo/buscar/`).

## Configuración

1. **Snippets → Configuración ERP**: colocá host, puerto, base, usuario y
   contraseña de un usuario **solo lectura** del PostgreSQL. La contraseña se
   cifra al guardar.
   - Desde el editor usá el botón **Probar conexión**.
   - Las columnas de stock/dependencias asumidas son las descritas en el
     panel “Stock y dependencias”; adaptalas a tu esquema real.
   - Activá la configuración cuando ya no sea la de ejemplo.
2. **Snippets → Categorías ERP**: definí cada categoría con:
   - la tabla/vista de productos (`tabla_origen`) y sus columnas
     (`campo_codigo`, `campo_nombre`, `campo_extra1..3`);
   - el método de búsqueda (`codigo_exacto`, `segmento`, `descripcion`,
     `multiple`) y el texto de ayuda del modal.
3. **Páginas → Catálogo**: la página pública ya existe (slug `catalogo`).
   Agregá su enlace al menú en `base_automotive.html` si hace falta.

## Seguridad

- Contraseña **cifrada** con `cryptography.fernet` (fallback: cifrado
  autenticado con la biblioteca estándar si la dependencia no está).
- Consultas **parametrizadas**; identificadores citados con `psycopg2.sql`.
- Conexión **solo lectura** con `statement_timeout=4000ms` y `connect_timeout=8s`.
- Se **cachean las categorías** (5 min, invalidadas al guardar), nunca los resultados.
- Máx. 50 resultados por consulta; errores con mensajes claros y sin exponer
  detalles de conexión.

## Endpoint

`GET|POST /api/catalogo/buscar/?categoria_id=<id>&q=<term>` (o `q1..q3` para
`multiple`). Respuesta:

```json
{
  "ok": true,
  "productos": [
    {
      "codigo": "ABC123",
      "nombre": "Filtro de aceite",
      "extra1": "Marca: X",
      "disponibilidad": [
        {"dependencia": "Taller Central", "cantidad": 5},
        {"dependencia": "Sucursal Plaza", "cantidad": 0}
      ]
    }
  ]
}
```

Si no hay configuación activa o la consulta falla, devuelve `{"ok": false,
"error": "<mensaje claro>"}`.