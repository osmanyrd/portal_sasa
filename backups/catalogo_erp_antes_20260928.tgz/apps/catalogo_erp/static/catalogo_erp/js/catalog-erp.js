/* Catálogo ERP — modal de consulta de disponibilidad.
   Abre el modal por categoría, arma el formulario según el método de
   búsqueda, consulta /api/catalogo/buscar/ y renderiza los resultados. */
(function () {
  "use strict";

  var raiz = document.querySelector("[data-catalogo-erp]");
  if (!raiz) return;

  var API_URL = raiz.dataset.apiUrl || "/api/catalogo/buscar/";
  var modalEl = document.getElementById("catalogoErpModal");
  var modalInstancia = window.bootstrap
    ? new bootstrap.Modal(modalEl)
    : null;

  var categoriaActual = null;

  var etiquetasCampos = {
    codigo_exacto: { label: "Código exacto", name: "q", ph: "Ej.: FIL-0051" },
    segmento: { label: "Segmento / prefijo", name: "q", ph: "Ej.: LUB-" },
    descripcion: { label: "Descripción", name: "q", ph: "Palabras clave (ej.: filtro aceite)" },
    multiple: [
      { name: "q1", label: "Código", ph: "Código…" },
      { name: "q2", label: "Nombre", ph: "Nombre…" },
      { name: "q3", label: "Detalle", ph: "Detalle…" },
    ]
  };

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function el(html) {
    var tmp = document.createElement("template");
    tmp.innerHTML = html.trim();
    return tmp.content.firstElementChild;
  }

  // ── Construcción del formulario ────────────────────────────────
  function construirCampos(metodo) {
    var contenedor = document.getElementById("catalogoErpCampos");
    contenedor.innerHTML = "";
    var def = etiquetasCampos[metodo] || etiquetasCampos.codigo_exacto;

    if (metodo === "multiple") {
      def.forEach(function (campo, i) {
        var div = el(
          '<div class="col-12 col-md-4">' +
            '<label for="catErpF' + i + '">' + esc(campo.label) + "</label>" +
            '<input class="form-control" id="catErpF' + i + '" name="' + campo.name +
            '" placeholder="' + esc(campo.ph) + '" autocomplete="off">' +
          "</div>"
        );
        contenedor.appendChild(div);
      });
    } else {
      var d = el(
        '<div class="col-12">' +
          '<label for="catErpFq">' + esc(def.label) + "</label>" +
          '<input class="form-control" id="catErpFq" name="' + def.name +
          '" placeholder="' + esc(def.ph) + '" autocomplete="off">' +
        "</div>"
      );
      contenedor.appendChild(d);
    }
  }

  function abrirModal(boton) {
    categoriaActual = {
      id: boton.dataset.categoriaId,
      nombre: boton.dataset.categoriaNombre,
      metodo: boton.dataset.metodo || "codigo_exacto",
      ayuda: boton.dataset.ayuda || ""
    };
    document.getElementById("catalogoErpModalCat").textContent = categoriaActual.nombre;
    var ayudaEl = document.getElementById("catalogoErpAyuda");
    ayudaEl.innerHTML = (categoriaActual.ayuda || "Ingresá los datos para consultar la disponibilidad.")
      .split("\n")
      .map(function (linea) { return esc(linea.replace(/\r/g, "")) || "&nbsp;"; })
      .join("<br>");
    construirCampos(categoriaActual.metodo);
    limpiarResultados();
    document.getElementById("catalogoErpForm").reset();
    if (modalInstancia) modalInstancia.show();
    var primer = document.querySelector("#catalogoErpCampos input");
    if (primer) setTimeout(function () { primer.focus(); }, 250);
  }

  function limpiarResultados() {
    document.getElementById("catalogoErpResultados").innerHTML = "";
    document.getElementById("catalogoErpError").classList.add("d-none");
    document.getElementById("catalogoErpLoader").classList.add("d-none");
  }

  function mostrarError(msg) {
    var e = document.getElementById("catalogoErpError");
    e.textContent = msg;
    e.classList.remove("d-none");
  }

  // ── Consulta AJAX ─────────────────────────────────────────────
  function buscar(event) {
    if (event) event.preventDefault();
    if (!categoriaActual) return;

    limpiarResultados();
    document.getElementById("catalogoErpLoader").classList.remove("d-none");

    var fd = new FormData(document.getElementById("catalogoErpForm"));
    var parametros = new URLSearchParams({ categoria_id: categoriaActual.id });
    if (categoriaActual.metodo === "multiple") {
      ["q1", "q2", "q3"].forEach(function (k) {
        var v = String(fd.get(k) || "").trim();
        if (v) parametros.append(k, v);
      });
    } else {
      var q = String(fd.get("q") || "").trim();
      if (q) parametros.append("q", q);
    }

    fetch(API_URL + "?" + parametros.toString(), { credentials: "same-origin" })
      .then(function (resp) { return resp.json().catch(function () { return null; }); })
      .then(function (datos) {
        document.getElementById("catalogoErpLoader").classList.add("d-none");
        if (!datos) { mostrarError("El servidor no respondió correctamente."); return; }
        if (!datos.ok) { mostrarError(datos.error || "No se pudo completar la consulta."); return; }
        renderizar(datos.productos || []);
      })
      .catch(function () {
        document.getElementById("catalogoErpLoader").classList.add("d-none");
        mostrarError("No se pudo conectar con el catálogo.");
      });
  }

  // ── Renderizado de resultados ─────────────────────────────────
  function renderizar(productos) {
    var cont = document.getElementById("catalogoErpResultados");
    cont.innerHTML = "";

    if (!productos.length) {
      cont.appendChild(el(
        '<div class="catalogo-erp__vacio-aviso">' +
          '<i class="bi bi-search" aria-hidden="true"></i>' +
          "No se encontraron productos con esos criterios. Probá de nuevo." +
        "</div>"
      ));
      return;
    }

    cont.appendChild(el(
      '<p class="catalogo-erp__resumen">' +
        "<span><strong>" + productos.length + "</strong> producto(s) encontrado(s)" +
        " (máx. 50)".replace(" (máx. 50)", productos.length >= 50 ? " — se muestran los primeros 50" : "") +
        "</span>" +
        '<span class="small">Disponibilidad según dependencia</span>' +
      "</p>"
    ));

    productos.forEach(function (p) {
      cont.appendChild(detalleProducto(p));
    });
  }

  function detalleProducto(p) {
    var extrasHtml = "";
    ["extra1", "extra2", "extra3"].forEach(function (k) {
      if (p[k] != null && String(p[k]) !== "") {
        extrasHtml += '<span><i class="bi bi-info-circle me-1" aria-hidden="true"></i>' +
          esc(p[k]) + "</span>";
      }
    });

    var dispHtml;
    if (p.disponibilidad && p.disponibilidad.length) {
      var mayorme = null;
      p.disponibilidad.forEach(function (d) {
        if (mayorme == null || d.cantidad > mayorme.cantidad) mayorme = d;
      });
      dispHtml = '<div class="catalogo-erp__pendiente">' + p.disponibilidad.map(function (d) {
        var ok = d.cantidad > 0;
        var top = mayorme && d.cantidad > 0 && d.cantidad === mayorme.cantidad;
        var cant = esc(ok ? "Disponible · " + d.cantidad : "Sin stock");
        var clase = ok ? "catalogo-erp__cantidad--ok" : "catalogo-erp__cantidad--no";
        if (top) clase += " catalogo-erp__cantidad--top";
        return '<span class="catalogo-erp__dep" title="' + esc(d.dependencia) + '">' +
          '<i class="bi bi-geo-alt" aria-hidden="true"></i>' +
          "<span>" + esc(d.dependencia || "Sin dependencia") + "</span>" +
          '<span class="catalogo-erp__cantidad ' + clase + '">' + cant + "</span>" +
        "</span>";
      }).join("") + "</div>";
    } else {
      dispHtml = '<p class="catalogo-erp__sin-stock">' +
        '<i class="bi bi-exclamation-circle me-1" aria-hidden="true"></i>Sin registros de disponibilidad' +
      "</p>";
    }

    return el(
      '<article class="catalogo-erp__producto">' +
        '<div class="catalogo-erp__producto-cabeza">' +
          '<span class="catalogo-erp__producto-codigo">' + esc(p.codigo) + "</span>" +
        "</div>" +
        '<h3 class="catalogo-erp__producto-nombre">' + esc(p.nombre || "—") + "</h3>" +
        (extrasHtml ? '<div class="catalogo-erp__producto-extras">' + extrasHtml + "</div>" : "") +
        dispHtml +
      "</article>"
    );
  }

  // ── Enlace de eventos ─────────────────────────────────────────
  document.querySelectorAll("[data-abrir-modal]").forEach(function (boton) {
    boton.addEventListener("click", function () { abrirModal(boton); });
  });

  var form = document.getElementById("catalogoErpForm");
  if (form) form.addEventListener("submit", buscar);

  // Si la importación de Bootstrap falló, igual permitís consultar la primera.
  if (!modalInstancia) {
    try {
      modalEl.style.display = "block";
      modalEl.classList.add("show");
    } catch (e) { /* noop */ }
  }
})();